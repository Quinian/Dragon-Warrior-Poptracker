-- Dragon Warrior Location Loader

-- Brain this holds all logic
Tracker:AddLocations("locations/locations.json")

-- Map Pins ONLY

-- Main Map
Tracker:AddLocations("locations/world_map.json")

-- Sub Maps
-- Tracker:AddLocations("locations/brecconary.json") Currently Unused
-- Tracker:AddLocations("locations/cantlin.json") Currently Unused
-- Tracker:AddLocations("locations/charlock_1f.json") Currently Unused
-- Tracker:AddLocations("locations/charlock_b1.json") Currently Unused
Tracker:AddLocations("locations/charlock_b7.json")
Tracker:AddLocations("locations/charlock_connections.json")
Tracker:AddLocations("locations/erdricks_cave.json")
Tracker:AddLocations("locations/garinham.json")
Tracker:AddLocations("locations/garins_grave.json")
Tracker:AddLocations("locations/hauksness.json")
Tracker:AddLocations("locations/kol.json")
Tracker:AddLocations("locations/mountain_cave.json")
Tracker:AddLocations("locations/rimuldar.json")
Tracker:AddLocations("locations/swamp_cave.json")
Tracker:AddLocations("locations/tantegel.json")


